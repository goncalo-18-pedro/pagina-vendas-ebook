
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";

// Component to handle AI Image generation for the page
const GeneratedImage = ({ prompt, alt, className }: { prompt: string, alt: string, className?: string }) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateImage = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: `A professional, high-quality, empathetic illustration or photo for a self-help ebook. ABSOLUTELY NO TEXT, NO WORDS, NO TITLES, NO LETTERS, NO SIGNATURES. The image must be purely visual. Style: Modern, clean, warm lighting, cinematic. Subject: ${prompt}` }],
          },
          config: {
            imageConfig: {
              aspectRatio: "16:9"
            }
          }
        });

        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setImageUrl(`data:image/png;base64,${part.inlineData.data}`);
            break;
          }
        }
      } catch (error) {
        console.error("Error generating image:", error);
      } finally {
        setLoading(false);
      }
    };

    generateImage();
  }, [prompt]);

  if (loading) {
    return (
      <div className={`bg-slate-200 animate-pulse flex items-center justify-center rounded-2xl shadow-inner ${className}`}>
        {/* Espaço reservado limpo durante o carregamento */}
      </div>
    );
  }

  return imageUrl ? (
    <img src={imageUrl} alt={alt} className={`rounded-2xl shadow-xl object-cover ${className}`} />
  ) : (
    <div className={`bg-slate-300 flex items-center justify-center rounded-2xl ${className}`}>
        {/* Espaço reservado limpo em caso de erro */}
    </div>
  );
};

const App = () => {
  const [today] = useState(new Date().toLocaleDateString('pt-BR'));

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-indigo-50">
      {/* 1. HEADLINE E 2. SUBHEADLINE */}
      <header className="max-w-5xl mx-auto pt-24 pb-20 px-6 text-center">
        <div className="inline-block px-4 py-1.5 mb-6 text-sm font-semibold tracking-wide text-indigo-700 uppercase bg-indigo-100 rounded-full animate-bounce">
          Guia prático para o trabalhador exausto
        </div>
        <h1 className="text-5xl md:text-6xl font-extrabold text-slate-900 leading-tight mb-8">
          Você acorda cansado de um dia que <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 italic">ainda nem começou?</span>
        </h1>
        <p className="text-xl md:text-2xl text-slate-600 leading-relaxed max-w-3xl mx-auto">
          Sentir-se preso em um trabalho que drena sua energia não é um sinal de preguiça ou fracasso. É o resultado silencioso de um desgaste emocional que ninguém te ensinou a gerenciar.
        </p>
      </header>

      {/* Hero Image Section */}
      <section className="max-w-5xl mx-auto px-6 mb-20">
        <GeneratedImage 
          prompt="A tired worker in an office looking out the window at a bright sunset, feeling a moment of inner peace and hope, soft colors, purely visual, no words" 
          alt="Trabalhador buscando paz"
          className="w-full aspect-video"
        />
      </section>

      {/* 3. IDENTIFICAÇÃO COM O LEITOR */}
      <section className="max-w-5xl mx-auto py-20 px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-4xl font-bold mb-8 text-slate-900">A angústia que começa no domingo à noite.</h2>
            <div className="space-y-6 text-lg text-slate-700">
              <p>
                Você conhece bem essa sensação: o aperto no peito quando o sol se põe no domingo. A segunda-feira não é apenas mais um dia de trabalho, é o reinício de um ciclo que parece não ter fim.
              </p>
              <p>
                Você vive no automático. Cumpre horários, responde e-mails e resolve problemas, mas sente que sua vida está estacionada enquanto o tempo passa. 
              </p>
              <p className="font-semibold text-indigo-900">
                O medo de sair por causa dos boletos é real, mas o preço de continuar sem ferramentas para proteger sua mente é ainda maior.
              </p>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <GeneratedImage 
              prompt="Conceptual artistic visual of a person breaking free from invisible chains, bright emotional colors, no text anywhere" 
              alt="Quebrando correntes mentais"
              className="w-full aspect-square"
            />
          </div>
        </div>
      </section>

      {/* 4. APRESENTAÇÃO DO EBOOK */}
      <section className="bg-indigo-900 text-white py-24 px-6 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-800 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl opacity-50"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-900 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl opacity-30"></div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="text-sm font-bold uppercase tracking-widest text-indigo-300 mb-6 block">Um novo caminho é possível</span>
          <h2 className="text-4xl md:text-5xl font-bold mb-10 italic">Manual de Sobrevivência Emocional Para Quem Odeia o Próprio Trabalho</h2>
          <div className="max-w-2xl mx-auto text-xl text-indigo-100 space-y-8 text-center leading-relaxed">
            <p>
              Este não é um livro de autoajuda milagrosa. Não vamos dizer para você pedir demissão amanhã sem planejamento, nem prometer que você ficará rico trabalhando de pijama.
            </p>
            <p className="bg-white/10 p-6 rounded-2xl backdrop-blur-sm border border-white/20">
              Este é um guia prático e humano para quem precisa continuar onde está, mas não quer mais adoecer por causa disso. É sobre como criar defesas mentais e preservar sua dignidade emocional.
            </p>
          </div>
        </div>
      </section>

      {/* 5. O QUE O LEITOR VAI ENCONTRAR */}
      <section className="max-w-6xl mx-auto py-24 px-6">
        <h2 className="text-4xl font-bold mb-16 text-center text-slate-900">O que este guia oferece</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { title: "Clareza Mental", text: "Entenda por que você se sente assim e como separar sua identidade do seu cargo.", icon: "🧠" },
            { title: "Limites Invisíveis", text: "Técnicas para estabelecer barreiras que impedem o estresse de entrar na sua casa.", icon: "🛡️" },
            { title: "Sobrevivência", text: "Estratégias para lidar com ambientes tóxicos e colegas difíceis com sabedoria.", icon: "🌿" },
            { title: "Sua Próxima Fase", text: "Como usar o trabalho atual como trampolim emocional para o que você realmente quer.", icon: "🚀" }
          ].map((item, idx) => (
            <div key={idx} className="p-8 bg-white rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
              <div className="text-4xl mb-4">{item.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-slate-900">{item.title}</h3>
              <p className="text-slate-600 leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 6. PARA QUEM É / PARA QUEM NÃO É */}
      <section className="bg-slate-50 py-24 px-6 rounded-[3rem] mx-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16">
            <div className="bg-emerald-50 p-10 rounded-3xl border border-emerald-100">
              <h3 className="text-2xl font-bold mb-8 text-emerald-900">Ideal para quem:</h3>
              <ul className="space-y-5">
                {["Trabalha CLT e se sente esgotado", "Não pode pedir as contas por causa de dinheiro", "O trabalho está afetando a vida pessoal", "Quer recuperar a paz mental"].map((t, i) => (
                  <li key={i} className="flex items-center text-emerald-800">
                    <span className="mr-3 text-emerald-500 font-bold text-xl">✓</span>
                    <p className="font-medium">{t}</p>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-rose-50 p-10 rounded-3xl border border-rose-100">
              <h3 className="text-2xl font-bold mb-8 text-rose-900">Não compre se:</h3>
              <ul className="space-y-5">
                {["Busca fórmulas mágicas de riqueza", "Quer incentivo para sair sem plano", "Não quer refletir sobre si mesmo"].map((t, i) => (
                  <li key={i} className="flex items-center text-rose-800">
                    <span className="mr-3 text-rose-500 font-bold text-xl">✕</span>
                    <p className="font-medium">{t}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CTA & PRICING */}
      <section id="pricing" className="py-24 px-6 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <div className="bg-amber-50 border-2 border-amber-200 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-red-600 text-white px-8 py-2 rotate-45 translate-x-12 translate-y-6 text-sm font-bold shadow-lg">
              50% OFF
            </div>
            
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Acesso Imediato ao Manual</h2>
            <p className="text-slate-600 mb-8">Comece sua jornada de recuperação emocional hoje mesmo.</p>
            
            <div className="flex flex-col items-center justify-center mb-10">
              <span className="text-slate-400 line-through text-2xl mb-1">R$ 35,60</span>
              <div className="flex items-baseline gap-2">
                <span className="text-slate-900 text-3xl font-bold">R$</span>
                <span className="text-6xl md:text-7xl font-black text-indigo-600">17,80</span>
              </div>
              <p className="mt-4 text-emerald-600 font-bold bg-emerald-50 px-4 py-1 rounded-full text-sm">
                Oferta válida somente hoje, {today}
              </p>
            </div>

            <a 
              href="#" 
              className="group relative inline-flex items-center justify-center w-full md:w-auto px-12 py-6 text-2xl font-bold text-white transition-all duration-200 bg-indigo-600 rounded-2xl hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-600 shadow-[0_10px_40px_-10px_rgba(79,70,229,0.5)]"
            >
              Comprar Agora com Desconto
              <span className="ml-3 group-hover:translate-x-1 transition-transform">→</span>
            </a>
            
            <p className="mt-8 text-slate-500 text-sm">
              Pagamento único • Acesso vitalício • Entrega digital instantânea
            </p>
          </div>
        </div>
      </section>

      {/* 7. QUEBRA DE OBJEÇÃO */}
      <section className="max-w-3xl mx-auto py-24 px-6 border-t border-slate-100">
        <h2 className="text-4xl font-bold mb-12 text-center text-slate-900 italic">Dúvidas Frequentes</h2>
        <div className="space-y-12">
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
              <span className="w-8 h-8 flex items-center justify-center bg-indigo-100 text-indigo-600 rounded-full text-sm">?</span>
              "É apenas mais um conteúdo motivacional?"
            </h3>
            <p className="text-lg text-slate-700 leading-relaxed">
              Não. Nós evitamos frases de efeito vazias. O foco aqui é realismo e ferramentas psicológicas práticas para o trabalhador comum que precisa lidar com a realidade de um escritório ou de uma fábrica todos os dias.
            </p>
          </div>
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-3">
              <span className="w-8 h-8 flex items-center justify-center bg-indigo-100 text-indigo-600 rounded-full text-sm">?</span>
              "Vai me ajudar se eu não puder sair agora?"
            </h3>
            <p className="text-lg text-slate-700 leading-relaxed">
              Esse é exatamente o objetivo principal. O guia foi escrito pensando em quem está na fase da "ponte": você sabe que quer algo diferente, mas ainda precisa cumprir seu horário. Ensinamos como atravessar essa ponte sem se quebrar no caminho.
            </p>
          </div>
        </div>
      </section>

      {/* 9. ENCERRAMENTO EMOCIONAL */}
      <footer className="bg-slate-900 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-12">
             <GeneratedImage 
              prompt="A silhouette of a person standing at a peaceful coastline at sunrise, feeling calm and ready, no text on image" 
              alt="Liberdade emocional"
              className="w-48 h-48 mx-auto rounded-full object-cover border-4 border-white/10"
            />
          </div>
          <p className="text-2xl md:text-3xl text-indigo-200 italic leading-relaxed mb-12 max-w-2xl mx-auto font-serif">
            "Cuidar da sua mente não é um luxo, é sobrevivência."
          </p>
          <div className="pt-12 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
            <p className="text-slate-500">Manual de Sobrevivência Emocional © 2024</p>
            <div className="flex gap-8 text-slate-400 text-sm">
              <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-white transition-colors">Privacidade</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);
